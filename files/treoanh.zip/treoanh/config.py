RESET = '\033[0m'
BOLD = '\033[1m'
GREEN = '\033[92m'
RED = '\033[91m'
IMEI = "073f2983-ce78-4def-8573-5ce500c0fe8a-cd5d5f3ff8f374827248e13d2f7d64ca"
SESSION_COOKIES = {"_ga":"GA1.2.886892652.1753943117","_gid":"GA1.2.206003827.1753943117","ZConsent":"timestamp=1753943125758&location=https://zalo.me/pc","_zlang":"vn","zpsid":"V9k1.436350146.9.wCIoEHOfIsFK1Kbv6YbBOsDQELSb7tXM9XX_LHYMPlmas6d25wD7w7ufIsC","zpw_sek":"X7n5.436350146.a0.1WbzWnikHdZP0aHYEYv6U60C8nCv56GRJtaLBJHi2KfUQIS2T60KJ5L2TpvQ4tjQPY3vLOGSjrgwByrqa4P6U0","__zi":"3000.SSZzejyD0jydXQckra00a3BBfxQL71AQV8UZjTvJ4vbxWA3vtb0GrdE3fllKK13KEG.1","__zi-legacy":"3000.SSZzejyD0jydXQckra00a3BBfxQL71AQV8UZjTvJ4vbxWA3vtb0GrdE3fllKK13KEG.1","ozi":"2000.SSZzejyD0jydXQckra00a3BBfxQK71AQVOUaljbK49LuWQExtHeNa7pEgxZR61sGCpCv.1","app.event.zalo.me":"9080915543201142412","_gat":"1","_ga_RYD7END4JE":"GS2.2.s1753943117$o1$g1$t1753943364$j60$l0$h0"}
API_KEY = 'api_key'
SECRET_KEY = 'secret_key'
PREFIX = "?"
ADMIN = "5265645895155035640"
EXPIRATION_DATE= "ngày/tháng/năm giờ:phút:giây"
LICENSE_ADMIN = "admin người cấp ngày cho bot"  # Gắn ID người có quyền /giahan, /trangthai
