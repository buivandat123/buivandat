chrome.runtime.onInstalled.addListener(() => {
  console.log('Token Extractor installed');
});
