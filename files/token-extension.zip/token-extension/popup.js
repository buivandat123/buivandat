let currentToken = null;

async function getToken() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  const results = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      const allKeys = Object.keys(localStorage);
      
      for (let key of allKeys) {
        if (key.toLowerCase().includes('token')) {
          return {
            key: key,
            value: localStorage.getItem(key)
          };
        }
      }
      
      return null;
    }
  });
  
  return results[0].result;
}

function displayToken(tokenData) {
  const tokenDisplay = document.getElementById('tokenDisplay');
  const copyBtn = document.getElementById('copyBtn');
  
  if (tokenData && tokenData.value) {
    currentToken = tokenData.value;
    tokenDisplay.className = 'token-text';
    tokenDisplay.textContent = tokenData.value;
    copyBtn.disabled = false;
  } else {
    currentToken = null;
    tokenDisplay.className = 'no-token';
    tokenDisplay.textContent = 'Không tìm thấy token. Nhấn Reload để thử lại.';
    copyBtn.disabled = true;
  }
}

async function copyToClipboard() {
  if (!currentToken) return;
  
  try {
    await navigator.clipboard.writeText(currentToken);
    
    const successMsg = document.getElementById('successMsg');
    successMsg.classList.add('show');
    
    setTimeout(() => {
      successMsg.classList.remove('show');
    }, 2000);
  } catch (err) {
    alert('Lỗi khi copy: ' + err);
  }
}

async function reloadToken() {
  const tokenDisplay = document.getElementById('tokenDisplay');
  tokenDisplay.className = 'no-token';
  tokenDisplay.textContent = 'Đang tìm token...';
  
  const tokenData = await getToken();
  displayToken(tokenData);
}

document.getElementById('copyBtn').addEventListener('click', copyToClipboard);
document.getElementById('reloadBtn').addEventListener('click', reloadToken);

(async function init() {
  const tokenData = await getToken();
  displayToken(tokenData);
})();
